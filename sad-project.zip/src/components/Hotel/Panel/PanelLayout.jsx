import { Box, Container, CssBaseline } from '@mui/material';
import React from 'react';
import SideBar from './components/SideBar';
import NavBar from "../../NavBar/newNavBar"
import "./panelLayout.css"

const PanelLayout = ({children}) => {
    return (
        <div>
            <Box className="navbar">
                <NavBar />
            </Box>

            <Box sx={{ height: "auto",width: '100%', display: "flex", position:"absolute" }}>
                <SideBar />
                {children}
            </Box>
        </div>

    );
}
 
export default PanelLayout;


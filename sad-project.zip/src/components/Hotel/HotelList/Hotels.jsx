import { Container, Grid } from '@mui/material';
import React, { useState, useEffect } from 'react';
import HotelCard from './components/HotelCard';

function Hotels (prop) {
    const [hotels, setHotels] = useState([]);

    useEffect(() => {
        fetch("http://127.0.0.1:8000/api/hotel/")
            .then((res) => res.json())
            .then(data => setHotels(data))
    }, [])

    return (
        <Container>
            <Grid container sx={{ m: 3 }}>
                {hotels.map((hotel, index) => (
                    <Grid item key={index} xs={12} md={12} lg={12} xl={12}>
                        <HotelCard hotel={hotel} />
                    </Grid>
                ))}
            </Grid>
        </Container>
    );
}

export default Hotels;
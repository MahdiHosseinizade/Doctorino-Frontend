import React from 'react';

export default function (props) {
    return (
        <div>
            <h1>Dashboard</h1>
        </div>
    );
}
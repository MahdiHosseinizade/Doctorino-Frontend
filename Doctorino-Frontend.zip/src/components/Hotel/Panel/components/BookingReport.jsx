import React from 'react';

export default function BookingReport (props) {
    return (
        <div>
            <h1>BookingReport</h1>
            <h1>BookingReport</h1>
            <h1>BookingReport</h1>
            <h1>BookingReport</h1>
            <h1>BookingReport</h1>
            <h1>BookingReport</h1>
            <h1>BookingReport</h1>
            <h1>BookingReport</h1>
            <h1>BookingReport</h1>
            <h1>BookingReport</h1>
        </div>
    );
}
import React from "react";

export default function ChangePassword(props) {
  return (
    <div>
      <h1>ChangePassword</h1>
    </div>
  );
}

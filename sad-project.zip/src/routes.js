// import DoctorLogin from "./components/Doctor.jsx/doctorLogin";
// import doctorPanel from "./components/Doctor.jsx/doctorPanel";
import Login from "./components/Login/Login";
import SignUpPage from "./components/Sign Up/SignUp";
import NotFound from "./pages/NotFoundPage";
import HotelPanel from "./components/Hotel/Panel/HotelPanel";
import Hotels from "./components/Hotel/HotelList/Hotels";

const routes = [
    {path: '/signup', component: SignUpPage},
    {path: '/hotel-panel', component: HotelPanel},
    {path: '/hotels' , component: Hotels},
    {path:'/',component : Login , exact : true },
    {component:NotFound},
]

export default routes;
import React from "react";

export default function AppointmentReports(props) {
  return (
    <div>
      <h1>Appointment Reports</h1>
    </div>
  );
}

import React from "react";
import { Box, Container } from "@mui/material";
import SideBar from "./components/SideBar";
import NavBar from "../../NavBar/newNavBar";

export default function PaneLayout({ children }) {
  return (
    <Container
      sx={{
        display: "flex",
      }}
    >
      <Box className="navbar">
        <NavBar />
      </Box>

      <Box
        sx={{
          width: "100%",
        }}
      >
        <SideBar />
        {children}
      </Box>
    </Container>
  );
}

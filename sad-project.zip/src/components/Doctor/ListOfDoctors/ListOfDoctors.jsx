import { Container, Grid } from "@mui/material";
import React, { useState, useEffect } from "react";
import DoctorCard from "./components/DoctorCard";

export default function Doctors() {
  const [doctors, setDoctors] = useState([]);

  useEffect(() => {
    fetch("http://localhost:8000/doctors")
      .then((res) => res.json())
      .then((data) => setDoctors(data));
  }, []);

  return (
    <Container>
      <Grid container sx={{ m: 3 }}>
        {doctors.map((doctor, index) => (
          <Grid item key={index} xs={12} md={12} lg={12} xl={12}>
            <DoctorCard doctor={doctor} />
          </Grid>
        ))}
      </Grid> 
    </Container>
  );
}

import React from 'react';

export default function (props) {
    return (
        <div>
            <h1>BookingReport</h1>
        </div>
    );
}
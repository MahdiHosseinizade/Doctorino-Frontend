import React from 'react';


export default function Finances () {

    return (
        <div>
            <h1>Finances</h1>
            <h1>Finances</h1>
            <h1>Finances</h1>
            <h1>Finances</h1>
            <h1>Finances</h1>
        </div>
    );
}
import React from "react";

export default function FinanceIssues(props) {
  return (
    <div>
      <h1>Finance Issues</h1>
    </div>
  );
}
